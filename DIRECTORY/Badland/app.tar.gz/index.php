<script>
  window.location = "http://gamepix.blob.core.windows.net/livegames/40274/index.html?token=b81f11e82b7e73c002e916eb740b310e&sid=30057&gpx_country_code=PT&utm_source=www.gamepix.com&referer=http%3A%2F%2Fwww.gamepix.com%2Fplay%2Fbadland%2F&noplaypage=true";
</script>
