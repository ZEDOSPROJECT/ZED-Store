<script>
  window.location = "https://music.youtube.com";
</script>
