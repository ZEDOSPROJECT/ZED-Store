<script>
  window.location = "https://www.photopea.com/";
</script>