import os
import tarfile

os.system("clear")
descriptApp=""
print("Name of your app:")
nameApp = raw_input()
print("Your Website:")
websiteApp = raw_input()
typeApp=""
internetRequire=""

while(True):
    os.system("clear")
    print("Type of your app:\n")
    print("1 - GAME")
    print("2 - INTERNET")
    print("3 - MUSIC")
    print("4 - VIDEO")
    print("5 - PICTURE")
    print("6 - OFFICE")
    print("7 - DEVELOPMENT\n\n")
    print("Type of your app:  (0 to STOP)")

    n = int(raw_input())
    if(n<=0):
        exit()
    else:
        if(n==1):
            typeApp="game"
            break
        if(n==2):
            typeApp="internet"
            break
        if(n==3):
            typeApp="music"
            break
        if(n==4):
            typeApp="video"
            break
        if(n==5):
            typeApp="picture"
            break
        if(n==6):
            typeApp="office"
            break
        if(n==7):
            typeApp="developper"
            break

while(True):
    os.system("clear")
    print("Your App require internet acess?: (y/n)\n")
    n = int(raw_input())
    if(n=='y'):
        internetRequire="true"
        break
    else if(n=='n'):
        internetRequire="false"
        break
    else:
        exit()


print("Type a simple description of your app:      (0 to END)\n\n")


while(True):
    tmp=raw_input()
    if(tmp=="0"):
        break
    else:
        descriptApp=descriptApp+tmp+"\n"

try:
    os.mkdir("My Apps/"+nameApp)
    os.mkdir("My Apps/"+nameApp+"/src")
    os.mkdir("My Apps/"+nameApp+"/SCREENS")
except OSError:
    print ("Creation of the directorys %s failed" % nameApp)
else:
    f= open("My Apps/"+nameApp+"/app_manifest.json","w")
    f.write('{\n')
    f.write('\t"Name":"'+nameApp+'",\n')
    f.write('\t"Version":"1.0.0",\n')
    f.write('\t"Website":"https://google.com/",\n')
    f.write('\t"Platforms":"MOBILE|DESKTOP",\n')
    f.write('\t"Window":{\n')
    f.write('\t\t"Width":0,\n')
    f.write('\t\t"Height":0\n')
    f.write('\t},\n')
    f.write('\t"requireInternet":"'+internetRequire+''"{\n')
    f.write('}\n')
    f.close()

    f= open("My Apps/"+nameApp+"/src/index.php","w")
    f.write('<?php\n')
    f.write('\techo("Hello World")\n')
    f.write('?>\n')
    f.close()

    f= open("My Apps/"+nameApp+"/type","w")
    f.write(typeApp)
    f.close()

    f= open("My Apps/"+nameApp+"/DESCRIPTION","w")
    f.write(descriptApp)
    f.close()

    tf = tarfile.open("firstFiles.tar.gz")
    tf.extractall("My Apps/"+nameApp)

    os.rename("My Apps/"+nameApp+"/favicon.png","My Apps/"+nameApp+"/src/favicon.png")
    os.system("clear")

    print("Your work directory is My Apps/"+nameApp+"/src")

